import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-smile-to-vote',
  templateUrl: './smile-to-vote.component.html',
  styleUrls: ['./smile-to-vote.component.scss']
})
export class SmileToVoteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
