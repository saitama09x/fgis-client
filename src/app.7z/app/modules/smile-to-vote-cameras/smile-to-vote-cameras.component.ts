import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-smile-to-vote-cameras',
  templateUrl: './smile-to-vote-cameras.component.html',
  styleUrls: ['./smile-to-vote-cameras.component.scss']
})
export class SmileToVoteCamerasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
