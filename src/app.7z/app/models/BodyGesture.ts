export class BodyGesture {
    bodyGestureID: number
    name: string
    code: string
    updated_at: string

    constructor() {
        this.bodyGestureID = 0
    }
}