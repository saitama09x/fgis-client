export class WifiBeacon {
    wifiBeaconID: number
    deviceID: number
    name: string
    location: string
    description: string
    updated_at: string

    constructor() {
        this.wifiBeaconID = 0;
    }
}