export class Campaign {
    campaignID: number
    clientID: number
    title: string
    desc: string
    cameraID: number
    status: number
    updated_at: string

    constructor() {
        this.campaignID = 0
    }
}