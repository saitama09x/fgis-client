export class FacialExpression {
    facialExpID: number
    name: string
    code: string
    updated_at: string

    constructor() {
        this.facialExpID = 0
    }
}