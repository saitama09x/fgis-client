export class Camera {
    cameraID: number
    name: number
    location: number
    board_no: string
    screen_no: string
    updated_at: string

    constructor() {
        this.cameraID = 0;
    }
}