export class FaceSnapshot {
    faceSnapID: number
    deviceUuid: number
    batchId: string
    trackingFaceId: number
    faceId: number
    filename: string
    updated_at: string
}