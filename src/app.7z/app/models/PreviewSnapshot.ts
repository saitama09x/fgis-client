export class PreviewSnapshot {
    prevSnapID: number
    deviceUuid: number
    filename: string
    updated_at: string
}