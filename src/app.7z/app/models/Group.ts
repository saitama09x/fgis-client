export class Group {
    groupID: number
    clientID: number
    name: string
    desc: string
    updated_at: string

    constructor() {
        this.groupID = 0;
    }
}